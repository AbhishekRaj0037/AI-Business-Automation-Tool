#include<stdio.h>
void main()
{	int x,y,z;
    x= printf("BIT")>scanf("%d", &y)?(0||0)? printf("2"):printf("3"):'a'>'c'?printf("a"):printf("c");
    printf("\nx=%d\ny=%d", x,y);

    y= printf("Mesra")>scanf("%d", &x)?(0||0)? printf("2"):printf("3"):'a'>'c'?printf("a"):printf("c");

    z=x>y?printf("\n x"):printf("\n y");
    printf("\nx=%d\ny=%d, \n z=%d", x,y,z);
}

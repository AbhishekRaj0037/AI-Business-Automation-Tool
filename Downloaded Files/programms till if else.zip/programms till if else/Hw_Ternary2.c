#include<stdio.h>
void main()
{	int x=1,y=3,z=2;
   x>z?x>y?printf("x"):printf("y"):printf("z");
    printf("\n\n\n\n\nx=%d\ny=%d, \n z=%d", x,y,z);
}

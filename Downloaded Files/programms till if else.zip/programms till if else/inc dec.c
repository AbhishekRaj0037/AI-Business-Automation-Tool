#include<stdlib.h>
main()
{
    int a;
    int b;
    a=b=0;
    a= b+++ b+++ b++;
    printf("first  a= %d, b=%d\n\n",a,b);


    a=b=0;
     a= b+++ b+++ ++b;
   printf("second  a= %d, b=%d\n\n",a,b);


 a=b=0;
     a= b+++ ++b + b++;
   printf("third  a= %d, b=%d\n\n",a,b);

     a=b=0;
     a= b+++ ++b + ++b;
   printf("fourth  a= %d, b=%d\n\n",a,b);

        a=b=0;
     a= ++b+ b++ + b++;
   printf("fifth  a= %d, b=%d\n\n",a,b);

        a=b=0;
     a= ++b+ b++ + ++b;
   printf("sixth  a= %d, b=%d\n\n",a,b);

    a=b=0;
     a= ++b+ ++b + b++;
   printf("seventh  a= %d, b=%d\n\n",a,b);

    a=b=0;
     a= ++b+ ++b + ++b;
   printf("eighth  a= %d, b=%d\n\n",a,b);


}
